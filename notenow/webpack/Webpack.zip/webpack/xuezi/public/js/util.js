
//工具函数：返回公司名称

//使用ES6的模块方法导出下面这个函数
export function getCompanyName(){
    return 'TEDU.CN';
}