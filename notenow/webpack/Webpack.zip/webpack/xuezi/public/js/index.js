//导入另一个JS模块中的成员
import {getCompanyName} from './util';

//导入另两个CSS模块文件
import  '../css/base.css';
import  '../css/page.css';

//导入另两个图片模块文件
import pic10 from '../img/10.jpg';
import pic20 from '../img/20.jpg';

//创建一个DIV元素
var d = document.createElement('div');
//设置DIV元素内部的文字
d.innerHTML = '版权所有 2018：'+getCompanyName();
//修改DIV元素的class
d.className = 'box';

//创建一个IMG元素<img src="">
var img10 = new Image();  
//设置图片的SRC属性
img10.src = pic10;
//把图片追加为DIV元素的孩子
d.appendChild(img10);

//把DIV元素追加为BODY的孩子
document.body.appendChild(d);
 